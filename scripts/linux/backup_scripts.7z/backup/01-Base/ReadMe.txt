This folder should contain the inital backups of the production database following
the completion of all migration activites. It is recommended that a separate backup
be created that contains the entire content of the document schema. You can use the
BackupSOLADocuments script to create this backup using the F(ull) option.