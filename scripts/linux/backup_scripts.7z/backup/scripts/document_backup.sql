-- SQL script to create document backup table on the database to support
-- partial document backups. 

-- Table: document.document_backup

-- DROP TABLE document.document_backup;

CREATE TABLE document.document_backup
(
  id character varying(40) NOT NULL, -- Identifier for the document.
  nr character varying(15), -- Unique number to identify the document. Determined by the Digital Archive EJB when saving the document record.
  extension character varying(5), -- The file extension of the electronic file. E.g. pdf, tiff, doc, etc
  body bytea, -- The content of the electronic file.
  description character varying(100), -- A descriptive name to help recognizs the file such as the original file name.
  rowidentifier character varying(40), -- Identifies the all change records for the row in the document_historic table
  rowversion integer, -- Sequential value indicating the number of times this row has been modified.
  change_action character(1), -- Indicates if the last data modification action that occurred to the row was insert (i), update (u) or delete (d).
  change_user character varying(50), -- The user id of the last person to modify the row.
  change_time timestamp without time zone, -- The date and time the row was last modified.
  CONSTRAINT document_backup_pkey PRIMARY KEY (id)
);

COMMENT ON TABLE document.document_backup
  IS 'Extension to the LADM used by SOLA to perform partial backups of the document.document table.
Tags: FLOSS SOLA Extension';
COMMENT ON COLUMN document.document_backup.id IS 'Identifier for the document.';
COMMENT ON COLUMN document.document_backup.nr IS 'Unique number to identify the document. Determined by the Digital Archive EJB when saving the document record.';
COMMENT ON COLUMN document.document_backup.extension IS 'The file extension of the electronic file. E.g. pdf, tiff, doc, etc';
COMMENT ON COLUMN document.document_backup.body IS 'The content of the electronic file.';
COMMENT ON COLUMN document.document_backup.description IS 'A descriptive name to help recognizs the file such as the original file name.';
COMMENT ON COLUMN document.document_backup.rowidentifier IS 'Identifies the all change records for the row in the document_historic table';
COMMENT ON COLUMN document.document_backup.rowversion IS 'Sequential value indicating the number of times this row has been modified.';
COMMENT ON COLUMN document.document_backup.change_action IS 'Indicates if the last data modification action that occurred to the row was insert (i), update (u) or delete (d).';
COMMENT ON COLUMN document.document_backup.change_user IS 'The user id of the last person to modify the row.';
COMMENT ON COLUMN document.document_backup.change_time IS 'The date and time the row was last modified.';


